#include <iostream>//1. lien ket thu vien
using namespace std;
void soChinhPhuong();//2. khai bao ham
void soChinhPhuong()//3. dinh nghia ham
{
    int n;
    cout<<"Nhap vao so can kiem tra"<<endl;
    cin >> n;
    int dem = 0;
    int i=1;
    while(i<n)
    {
        if(i*i==n)
        {
            dem++; 
        }
        i++;
    }
    if(dem==0)
    {
        cout<<n<<" KHONG la so chinh phuong";
    }
    else
    {
        cout<<n<<" la so chinh phuong";
    }
}
int main()
{
    soChinhPhuong();//4. goi ham
    return 0;
}
