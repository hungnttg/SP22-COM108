#include <iostream>
using namespace std;
void trungBinhTong();//2.khai bao ham
void trungBinhTong()//3.dinh nghia ham
{
    int min,max,tong,dem;
    float tbtong;
    cout<<"Moi ban nhap min="; cin>>min; //nhap min
    cout<<" va max = ";        cin>>max; //nhap max
    tong=0;
    dem=0;
    for(int i=min;i<=max; i++)
    {
        if(i%2==0)//i chia cho 2 du 0 => i chia het cho 2
        {
            tong = tong + i;//tong += i; tong nhan gia tri bang tong cong them i
            dem = dem+1; // dem +=1; dem nhan gia tri bang dem cong them 1
        }
    }
    tbtong = tong/dem;
    cout<<" Trung binh tong la: "<<tbtong;
}
int main()
{
    trungBinhTong();//4.goi ham
    return 0;
}
