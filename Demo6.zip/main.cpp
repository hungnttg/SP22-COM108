#include <iostream>
using namespace std;
void trungbinhtong();//2.khai bao ham
void trungbinhtong()//dinh nghia ham
{
    cout<<"Nhap mang"<<endl;
    int a[5];
    for(int i=0;i<5;i++)
    {
        cin>>a[i];
    }
    //doc mang va tinh toan
    int tong = 0;
    int dem=0;
    float tbt = 0;
    for(int j=0;j<5;j++)
    {
        if(a[j]%3==0)//a[j] chia het cho 3
        {
            tong  = tong + a[j];// tong += a[j]
            dem = dem + 1;     //dem +=1;
        }
    }
    tbt = (float)tong/dem; //ép kiểu sang số thực
    cout<<"Trung binh tong la: "<< tbt<<endl;
}
int main()
{
    trungbinhtong();//4.goi ham
    return 0;
}
