#include <iostream>
using namespace std;
void sapXep();
void sapXep()
{
    cout<<"Nhap mang"<<endl;
    //1. Nhap mang
    int mang[6];
    for(int i=0;i<6;i++)
    {
        cin>>mang[i];//nhap tu ban phim vao cac thanh phan cua mang
    }
    //2. Doi cho
    for(int i=0;i<6;i++)
    {
        for(int j=0;j<6;j++)
        {
            int tam;
            if(mang[i]>mang[j])
            {
                tam = mang[i];
                mang[i] = mang[j];
                mang[j] = tam;
            }
        }
    }
    //in ra mang theo chieu giam dan
    cout<<"Sap xep giam dan "<<endl;
    for(int k=0;k<6;k++)
    {
        cout<<mang[k]<<" "<<endl;
    }
    //in ra mang theo chieu tang dan
    cout<<"Sap xep tang dan "<<endl;
    for(int k=6-1;k>=0;k--)
    {
        cout<<mang[k]<<" "<<endl;
    }
    
}
int main()
{
    sapXep();
    return 0;
}
