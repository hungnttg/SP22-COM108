#include <iostream>
using namespace std;
void timMinMax();//2. khai bao ham
void timMinMax()//3. dinh nghia ham
{
    int min, max;//khai bao bien min,max
    cout<<"Nhap mang"<<endl;
    int mang[6];
    for(int i=0;i<6;i++)
    {
        cin>>mang[i];//nhap du lieu tu ban phim vao tung phan tu trong mang
    }
    max = mang[0];//giả sử max là phần tử mang[0]
    min= mang[0];//giả sử min là phần tử mang[0]
    for(int i=0;i<6;i++)
    {
        if(mang[i]> max)
        {
            max = mang[i];
        }
        if(mang[i]< min)
        {
            min = mang[i];
        }
    }
    cout <<"Max la "<<max<<endl;//in gia tri max ra man hinh
    cout <<"Min la "<<min<<endl;//in gia tri min ra man hinh
}
int main()
{
    timMinMax();//4. goi ham
    return 0;
}
