#include <iostream>
using namespace std;
void doiCho(int a, int b);//2. Khai bao ham 
void doiCho(int a, int b)//3. dinh nghia (truyen tham so)
{
    int tam;
    tam = a;
    a = b;
    b = tam;
}
int main()
{
    int a,b;
    cout<<"a="; cin>>a;
    cout<<"b="; cin>>b;
    doiCho(a,b);//4. goi ham
    cout<<"Sau khi doi cho"<<endl;
    cout<<"a="<<a<<endl;
    cout<<"b="<<b<<endl;
    return 0;
}
