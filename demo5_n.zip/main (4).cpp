#include <iostream>
using namespace std;
bool namNhuan(int nam);//2.Khai bao
bool namNhuan(int nam)//3. dinh nghia
{
    if(nam%400 == 0)
    {
        cout<<nam<<" la nam nhuan";
        return true;
    }
    if(nam%4 == 0 && nam%100 != 0)
    {
        cout<<nam<<" la nam nhuan";
        return true;
    }
    cout<<nam<<" KHONG la nam nhuan";
    return false;
}
int main()
{
    int nam;
    cout<<"Moi nhap nam="; cin>>nam;
    namNhuan(nam);//4. goi ham
    return 0;
}
