#include<iostream>
using namespace std;
main()
{
	cout<<"Chuong trinh chu vi dien tich hinh tron"<<endl;
	float bankinh,chuvi,dientich;
	cin>>bankinh;
	chuvi=2*3.14*bankinh;
	dientich=3.14*(bankinh*bankinh);
	cout<<"Chu vi la"<<chuvi<<endl;
	cout<<"Dien tich la"<<dientich<<endl;
	system("pause");
	return 0;
}
