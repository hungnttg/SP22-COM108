#include<iostream>
using namespace std;
main()
{
	cout<<"Chuong trinh tinh diem trung binh"<<endl;
	int toan,ly,hoa,diemtrungbinh;
	cout<<"Toan";
	cin>>toan;
	cout<<"ly";
	cin>>ly;
	cout<<"Hoa";
	cin>>hoa;
    diemtrungbinh=(toan*3+ly*2+hoa*1)/6;
    cout<<"Diem trung binh la"<<diemtrungbinh<<endl;
    system("pause");
    return 0;
}

