#include <iostream>

using namespace std;

int main()
{
    cout<<"Tinh chu vi, dien tich \n";  //thong bao
    cout<<"Moi nhap canh a,b \n";       //thong bao
    int a,b,chuvi,dientich;             //khai bao bien        
    cin>>a;                             //nhap a
    cin>>b;                             //nhap b
    chuvi = (a+b)*2;                    //tinh chu vi
    dientich = a*b;                     //tinh dien tich
    cout<<"Chu vi la "<<chuvi<<endl;    //in ra chu vi
    cout<<"Dien tich la "<<dientich<<endl;//in dien tich

    return 0;
}
