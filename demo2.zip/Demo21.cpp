#include <iostream>

using namespace std;

int main()
{
    cout<<"Tinh tong, hieu "<<endl; //in thong bao
    cout<<"Moi nhap a va b"<<endl;  //in thong bao
    int a,b;                        //khai báo biến a và b
    cin>>a;                         //nhập từ bàn phím vào biến a
    cin>>b;                         //nhập từ bàn phím vào biến b
    int tong = a+b;                 //tinh tong
    int hieu = a-b;                 //tinh hieu
    cout<<"Tong la "<<tong<<endl;    //in ra màn hình tong
    cout<<"Hieu la "<<hieu<<endl;    //in ra man hinh hieu

    return 0;
}
