//ví dụ về viết chương trình có menu
//Tim usc_bsc
//kiem tra so nguyen to
#include <iostream>

using namespace std;
void menu();
int USCLN(int a, int b);
int USCLN(int a, int b)
{
    if(b==0)
    {
        return a;
    }
    else
    {
        return USCLN(b,a%b);
    }
}
int BSCNN(int a, int b);
int BSCNN(int a, int b)
{
    return (a*b)/USCLN(a,b);
}
void timUSC_BSC();
void timUSC_BSC()
{
    int a,b;
    cout<<"Moi ban nhap vao 2 so"<<endl;
    cout<<"a="; cin>>a;
    cout<<"b="; cin>>b;
    cout<<"USCLN la "<<USCLN(a,b)<<endl;
    cout<<"BSCNN la "<<BSCNN(a,b)<<endl;
    menu();
}
void kiemTraSoNguyenTo();
void kiemTraSoNguyenTo()
{
    int x;
    cout<<"Chuong trinh kiem tra so"<<endl;
    cout<<"Moi ban nhap so x=";
    cin>>x;
    if(x==(int)x)//1 so nguyen co phan nguyen bang chinh no
    {
        cout<<x<<" la mot so nguyen"<<endl;
        bool nt = true;//bien dieu khien so nguyen to
        bool cp = false;//bien dieu khien so chinh phuong
        //kiem tra xem co phai so nguyen to khong
        for(int i=2;i<x;i++)
        {
            if(x%i==0)//x chia cho i du 0
            {
                cout<<x<<" khong phai so nguyen to"<<endl;
                nt = false;//doi gia tri cho bien dieu khien
                break;
            }
        }
        if(nt==true)
        {
            cout<<x<<" la so nguyen to"<<endl;
        }
        //kiem tra xem co phai so chinh phuong khong
        for(int i=2;i<x;i++)
        {
            if(i*i==x)
            {
                cout<<x<<" la so chinh phuong";
                cp = true;//doi gia tri bien dieu khien
            }
        }
        if(cp==false)
        {
            cout<<x<<" khong phai so chinh phuong"<<endl;
        }
        
        
    }
    menu();
}

void menu()
{
    cout<<"Xin moi chon chuc nang"<<endl;
    cout<<"1. Kiem tra so nguyen to"<<endl;
    cout<<"2. USCLN, BSCNN"<<endl;
    cout<<"3. Thoat chuong trinh"<<endl;
    int chucnang;//khai bao bien chuc nang
    cin>>chucnang;//nhap chuc nang tu ban phim
    switch(chucnang)
    {
        case 1:
            kiemTraSoNguyenTo();
            break;
        case 2:
            timUSC_BSC();
            break;
        case 3:
            exit(0);
            break;
        default:
            menu();//nếu nhấn số khác thì gọi lại hàm menu
            break;
        
    }
}

int main()
{
    menu();
    return 0;
}
