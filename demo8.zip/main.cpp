//Ví dụ về truyền tham số cho hàm
#include <iostream>
//1.Khai báo hàm
float TinhTong(float a,float b);
//2.Định nghĩa hàm
float TinhTong(float a,float b)
{
    float c = a+b;
    return c;
}
using namespace std;

int main()
{
    float tong = TinhTong(5,3);//3. Gọi hàm: sử dụng phép truyền tham số
    cout<<"Tong la"<<tong<<endl;
    return 0;
}
