#include <iostream>
#include <math.h>
using namespace std;
void hocluc();
void gptb1();
void gptb2();
void tiendien();
void menu();
void hocluc()
{
    float diem;                                 //khai bao bien diem
    cout<<"Chuong trinh tinh hoc luc"<<endl;    //viet thong bao
    cout<<"diem=";                              //viet thong bao
    cin>>diem;                                  //nhap diem tu ban phim
    if(diem>=9)                                 //dung if...else
    {
        cout<<"xuat sac";
    }
    else if(diem>=8)
    {
        cout<<"gioi";
    }
    else if(diem>=6.5)
    {
        cout<<"Kha";
    }
    else if(diem>=5)
    {
        cout<<"TB";
    }
    else
    {
        cout<<"yeu kem";
    }
}
void gptb1()
{
    //Nhap lieu
    cout<<"Giai PTB1"<<endl;
    float a,b,x;
    cout<<"a="; cin>>a;
    cout<<"b="; cin>>b;
    //tinh toan
    if(a==0)
    {
        if(b==0)
        {
            cout<<"PT co VSN";
        }
        else
        {
           cout<<"PT vo nghiem"; 
        }
    }
    else
    {
        x = -b/a;
        cout<<"PT co nghiem x="<<x;
    }
}
void gptb2()
{
    cout<<"Giai ptb2"<<endl;
    float a,b,c,delta,x1,x2;
    cout<<"a="; cin>>a;         //nhap a
    cout<<"b="; cin>>b;         //nhap b
    cout<<"c="; cin>>c;         //nhap c
    delta = b*b-4*a*c;
    if(delta<0)
    {
        cout<<"PT vo nghiem";
    }
    else if(delta==0)
    {
        cout<<"PT co nghiem kep x="<<-b/(2*a);
    }
    else
    {
        x1 = (-b+sqrt(delta))/(2*a);
        x1 = (-b-sqrt(delta))/(2*a);
        cout<<"Nghiem la: x1="<<x1<<" va x2="<<x2;
    }
}
void tiendien()
{
    cout<<"Tinh tien dien"<<endl;
    int sodien,tien;
    cout<<"So dien="; cin>>sodien;
    if(sodien<=50)
    {
        tien = 1678*sodien;
    }
    else if(sodien<=100)
    {
        tien=(50*1678)+(sodien-50)*1734;
    }
    else if(sodien<200)
    {
        tien=(50*1678)+(50*1734)+(sodien-100)*2014;
    }
    else if(sodien<300)
    {
        tien = (50*1678)+(50*1734)+(100*2014)+(sodien-200)*2536;
    }
    else if(sodien<400)
    {
        tien = (50*1678)+(50*1734)+(100*2014)+(100*2536)+(sodien-300)*2834;
    }
    else
    {
        tien = (50*1678)+(50*1734)+(100*2014)+(100*2536)+(100*2834)+(sodien-400)*2927;
    }
    cout<<"So tien dien la: "<<tien;
}
void menu()
{
    cout<<"Xin moi ban chon chuc nang"<<endl;
    cout<<"1. Tinh hoc luc sinh vien"<<endl;
    cout<<"2. Giai phuong trinh bac 1"<<endl;
    cout<<"3. Giai phuong trinh bac 2"<<endl;
    cout<<"4. Tinh tien dien"<<endl;
    int chucnang;                   //khai bao bien chucnang
    cin>>chucnang;                  //nhap chucnang tu ban phim
    switch(chucnang)
    {
        case 1:
            hocluc();
            break;
        case 2:
            gptb1();
            break;
        case 3:
            gptb2();
            break;
        case 4:
            tiendien();
            break;
        default:
            cout<<"Khong co chuc nang vua nhap";
            break;
    }
}
int main()
{
    menu();
    return 0;
}
