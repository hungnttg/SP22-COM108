#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    cout<<"Giai ptb2"<<endl;
    float a,b,c,delta,x1,x2;
    cout<<"a="; cin>>a;         //nhap a
    cout<<"b="; cin>>b;         //nhap b
    cout<<"c="; cin>>c;         //nhap c
    delta = b*b-4*a*c;
    if(delta<0)
    {
        cout<<"PT vo nghiem";
    }
    else if(delta==0)
    {
        cout<<"PT co nghiem kep x="<<-b/(2*a);
    }
    else
    {
        x1 = (-b+sqrt(delta))/(2*a);
        x1 = (-b-sqrt(delta))/(2*a);
        cout<<"Nghiem la: x1="<<x1<<" va x2="<<x2;
    }
    return 0;
}
