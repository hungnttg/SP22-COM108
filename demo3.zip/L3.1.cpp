#include <iostream>

using namespace std;

int main()
{
    float diem;                                 //khai bao bien diem
    cout<<"Chuong trinh tinh hoc luc"<<endl;    //viet thong bao
    cout<<"diem=";                              //viet thong bao
    cin>>diem;                                  //nhap diem tu ban phim
    if(diem>=9)                                 //dung if...else
    {
        cout<<"xuat sac";
    }
    else if(diem>=8)
    {
        cout<<"gioi";
    }
    else if(diem>=6.5)
    {
        cout<<"Kha";
    }
    else if(diem>=5)
    {
        cout<<"TB";
    }
    else
    {
        cout<<"yeu kem";
    }

    return 0;
}
