#include <iostream>

using namespace std;

int main()
{
    //Nhap lieu
    cout<<"Giai PTB1"<<endl;
    float a,b,x;
    cout<<"a="; cin>>a;
    cout<<"b="; cin>>b;
    //tinh toan
    if(a==0)
    {
        if(b==0)
        {
            cout<<"PT co VSN";
        }
        else
        {
           cout<<"PT vo nghiem"; 
        }
    }
    else
    {
        x = -b/a;
        cout<<"PT co nghiem x="<<x;
    }
    return 0;
}
