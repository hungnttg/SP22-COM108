#include <iostream>

using namespace std;

int main()
{
    int x=5;
    cout<<"x co gia tri la "<<x;
    return 0;
}
