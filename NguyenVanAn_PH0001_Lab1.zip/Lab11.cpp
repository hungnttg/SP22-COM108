#include <iostream>

using namespace std;

int main()
{
    cout<<"Xin chao lop IT18103";

    return 0;
}
