#include <iostream>

using namespace std;

int main()
{
    string a="chao lop IT18103";//biến số nhận giá trị bằng "Xin chao lop IT18103"
    cout<<a; //in ra biến số

    return 0;
}
