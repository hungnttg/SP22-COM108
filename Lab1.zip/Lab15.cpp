#include <iostream>

using namespace std;

int main()
{
    cout<<"Moi ban nhap du lieu x="<<endl;      //in ra thông báo
    int x;                                      //khai báo biến x
    cin>>x;                                     //nhập giá trị từ bàn phím vào biến số x
    cout<<"Ban vua nhap so "<<x<<endl;          //in dữ liệu vừa nhập ra màn hình
    
    return 0;
}
