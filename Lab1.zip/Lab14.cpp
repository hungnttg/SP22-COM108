#include <iostream>

using namespace std;

int main()
{
    int x=5;
    float y=2.2;
    cout<<"x co gia tri la "<<x<<endl;
    cout<<"y co gia tri la "<<y<<endl;
    return 0;
}
