#include <iostream>
using namespace std;
void soSanh();//2. khai bao ham
void soSanh()//3. dinh nghia ham
{
    int so1,so2,so3,max;//khai bao bien
    cout<<"so1="; cin>>so1;//nhap so 1 tu ban phim
    cout<<"so2="; cin>>so2;//nhap so 2 tu ban phim
    cout<<"so3="; cin>>so3;//nhap so 3 tu ban phim
    max=so1;                //B1 - gan max = so 1
    if(so2>max)             //b2- so sanh max voi so 2
    {
        max = so2;          //max nhan gia tri la so 2
    }
    if(so3>max)             //b3- so sanh max voi so 3
    {
        max = so3;
    }
    cout<<"Max = "<<max<<endl;
}
int main()
{
    soSanh();//4. goi ham
    return 0;
}
