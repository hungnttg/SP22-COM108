#include <iostream>//1. lien ket thu vien
using namespace std;
void soNguyenTo();//2. khai bao ham
void soNguyenTo()//3. dinh nghia ham
{
    int n;//khai bao bien n
    cout<<"Nhap vao so can kiem tra"<<endl;
    cin >> n;
    int dem = 0;//khai bao bien dem va gan gia tri =0
    int i=2;
    while(i<n)
    {
        if(n%i==0)//n chia het cho i
        {
            dem++; // dem tang len 1
        }
        i++;
    }
    if(dem==0)
    {
        cout<<n<<" la so nguyen to";
    }
    else
    {
        cout<<n<<" KHONG la so nguyen to";
    }
}
int main()
{
    soNguyenTo();//4. goi ham
    return 0;
}
