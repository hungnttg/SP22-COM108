#include <iostream>
using namespace std;
//2.Khai bao
void trungBinhTong();
void soNguyenTo();
void soChinhPhuong();
void menu();
//3.Dinh nghia
void trungBinhTong()
{
    int min,max,tong,dem;
    float tbtong;
    cout<<"Moi ban nhap min="; cin>>min; //nhap min
    cout<<" va max = ";        cin>>max; //nhap max
    tong=0;
    dem=0;
    for(int i=min;i<=max; i++)
    {
        if(i%2==0)//i chia cho 2 du 0 => i chia het cho 2
        {
            tong = tong + i;//tong += i; tong nhan gia tri bang tong cong them i
            dem = dem+1; // dem +=1; dem nhan gia tri bang dem cong them 1
        }
    }
    tbtong = tong/dem;
    cout<<" Trung binh tong la: "<<tbtong;
     menu();
}
void soNguyenTo()
{
    int n;//khai bao bien n
    cout<<"Nhap vao so can kiem tra"<<endl;
    cin >> n;
    int dem = 0;//khai bao bien dem va gan gia tri =0
    int i=2;
    while(i<n)
    {
        if(n%i==0)//n chia het cho i
        {
            dem++; // dem tang len 1
        }
        i++;
    }
    if(dem==0)
    {
        cout<<n<<" la so nguyen to";
    }
    else
    {
        cout<<n<<" KHONG la so nguyen to";
    }
     menu();
}
void soChinhPhuong()
{
    int n;
    cout<<"Nhap vao so can kiem tra"<<endl;
    cin >> n;
    int dem = 0;
    int i=1;
    while(i<n)
    {
        if(i*i==n)
        {
            dem++; 
        }
        i++;
    }
    if(dem==0)
    {
        cout<<n<<" KHONG la so chinh phuong";
    }
    else
    {
        cout<<n<<" la so chinh phuong";
    }
     menu();
}
void menu()
{
    cout<<endl;
    cout<<"Xin moi nhap chuc nang: "<<endl;
    cout<<"1. Tinh trung binh tong"<<endl;
    cout<<"2. So nguyen to"<<endl;
    cout<<"3. So chinh phuong"<<endl;
    int chucnang;//khai bao bien chuc nang
    cin>>chucnang;//nhap tu ban phim so 1,2,3
    switch(chucnang)
    {
        case 1:
            trungBinhTong();
            break;
        case 2:
            soNguyenTo();
            break;
        case 3:
            soChinhPhuong();
            break;
        default:
            menu();
            break;
    }
}
int main()
{
    menu();
    return 0;
}
