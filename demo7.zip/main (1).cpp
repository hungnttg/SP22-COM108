#include <iostream>
using namespace std;
void demNguyenAmPhuAm();
void demNguyenAmPhuAm()
{
    cout<<"Moi nhap ho ten \n";
    //1. Khai bao bien
    int dem=0;//tong so ky tu
    int demNguyenAm = 0;//tong so nguyen am
    int demDauCach = 0;//tong so dau cach
    string s;//khai bao 1 chuoi dung de nhap ho ten
    //2. nhap gia tri vao chuoi
    getline(cin,s);//nhap 1 chuoi tu ban phim
    //3. tinh toan
    while(s[dem] != '\0')//khong phai ky tu enter
    {
        dem++;//nhap ky tu thi dem 1 lan
        if((s[dem]=='a')||(s[dem]=='e')||(s[dem]=='i')||(s[dem]=='o')||(s[dem]=='u'))
        {
            demNguyenAm++;
        }
        if(s[dem]==' ')
        {
            demDauCach++;
        }
    }
    cout<<"So nguyen am la: "<<demNguyenAm<<endl;
    cout<<"So phu am la: "<<dem-demNguyenAm-demDauCach<<endl;
}
int main()
{
    demNguyenAmPhuAm();
    return 0;
}
