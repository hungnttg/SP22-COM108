
#include <iostream>

using namespace std;

int main()
{
    double a;//khai bao bien a
    cin>>a;
    if(cin.fail())
    {
        cout<<"\n Ban vua nhap 1 ky tu";
    }
    else
    {
        if(a==(int)a)//a nhan gia tri bang phan nguyen cua a, vi du 3.5 => phan nguyen la 3
        {
            cout<<"\n So vua nhap la so nguyen "<<a<<endl;
        }
        else
        {
            cout<<"\n So vua nhap la 1 so thuc "<<a<<endl;
        }
    }

    return 0;
}
