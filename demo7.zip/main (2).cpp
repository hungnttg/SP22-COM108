#include <iostream>
using namespace std;
void dangNhap();
void dangNhap()
{
    string user = "admin";
    string pass = "12345";
    //1. Nhap lieu
    string u;//bien nhan gia tri nhap vao tu ban phim
    cout<<"Moi ban nhap username: ";
    getline(cin,u);//nhap tu ban phim vao chuoi u
    
    string p;//bien nhan gia tri nhap vao tu ban phim
    cout<<"Moi ban nhap password: ";
    getline(cin,p);//nhap tu ban phim vao chuoi p
    //2. xu ly
    while(user != u || pass != p)
    {
        cout<<"Sai user hoac sai pass"<<endl;
        //yeu cau nhap lai
        cout<<"Moi ban nhap username: ";
        getline(cin,u);
        cout<<"Moi ban nhap password: ";
        getline(cin,p);
    }
    cout<<"Dang nhap thanh cong"<<endl;
}
int main()
{
    dangNhap();
    return 0;
}
