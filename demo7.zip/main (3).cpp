#include <iostream>
#include <cstring>
using namespace std;
void sapxepchuoi();
void sapxepchuoi()
{
    //1. Nhap lieu
    char str[5];//luu du lieu nhap vao
    cout<<"Moi ban nhap 1 chuoi: ";
    for(int i=0;i<5;i++)
    {
        cin>>str[i];
    }
    cout<<"Chuoi truoc khi sap xep:"<<str<<endl;
    //2. săp xep
    char tam;
    for(int i=0;i<strlen(str)-1;i++)
    {
        for(int j=i+1;j<strlen(str);j++)
        {
            if(str[i]>str[j])
            {
                tam = str[i];
                str[i] = str[j];
                str[j] = tam;
            }
        }
    }
    //3. in ra man hinh
    cout<<"Sau khi sap xep: "<<endl;
    cout<<str;
    
}
int main()
{
    sapxepchuoi();
    return 0;
}
