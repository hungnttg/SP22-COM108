#include <iostream>

using namespace std;

int main()
{
    cout<<"Chuong trinh nhap San pham"<<endl;
    //nhap so
    int masp;
    cout<<"Moi ban nhap ma san pham \n";
    cin>>masp;
    //nhap chuoi
    string tensp;
    cout<<"Moi ban nhap Ten san pham \n";
    cin>>ws;
    getline(cin,tensp);
    //in ra thong tin vua nhap
    cout<<"Thong tin ban vua nhap"<<endl;
    cout<<"Ma sp: "<<masp<<endl;
    cout<<"Ten sp: "<<tensp<<endl;

    return 0;
}
